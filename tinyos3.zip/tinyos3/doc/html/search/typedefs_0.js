var searchData=
[
  ['ccb_565',['CCB',['../group__scheduler.html#gac3d551eb0caa1296280ea2278b4f1b11',1,'CCB():&#160;kernel_sched.h'],['../group__rlists.html#gac3d551eb0caa1296280ea2278b4f1b11',1,'CCB():&#160;util.h']]],
  ['cpu_5fcontext_5ft_566',['cpu_context_t',['../bios_8h.html#a6067c1395a75fc3e17f1ea6353065b54',1,'bios.h']]]
];
