var searchData=
[
  ['open_529',['Open',['../structfile__operations.html#a2732da2af03e1fc7ba0b63a529ab1411',1,'file_operations']]],
  ['owner_5fpcb_530',['owner_pcb',['../structthread__control__block.html#a74aa312623cb8be2bc719d5210b58c04',1,'thread_control_block']]]
];
