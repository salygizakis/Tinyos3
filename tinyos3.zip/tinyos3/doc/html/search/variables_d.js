var searchData=
[
  ['parent_531',['parent',['../structprocess__control__block.html#af20d0c36862c6def80024b4586ff8934',1,'process_control_block']]],
  ['phase_532',['phase',['../structthread__control__block.html#aa7e8e6a00c5f9f25210a49589ad818f8',1,'thread_control_block']]],
  ['pid_533',['pid',['../structprocinfo.html#a2e87cd5f0bdfe214832ec20f53deeb50',1,'procinfo']]],
  ['ppid_534',['ppid',['../structprocinfo.html#a790970c70987013b2712b7dd6d2b75b9',1,'procinfo']]],
  ['prev_535',['prev',['../group__rlists.html#ga280b77fdcee186bcaade02f76322d183',1,'resource_list_node']]],
  ['previous_5fthread_536',['previous_thread',['../structcore__control__block.html#ae71bba6ddbd8709c51cd85efc3904a4e',1,'core_control_block']]],
  ['pstate_537',['pstate',['../structprocess__control__block.html#ae3334dd8a5747f108124c7129c27eea5',1,'process_control_block']]]
];
