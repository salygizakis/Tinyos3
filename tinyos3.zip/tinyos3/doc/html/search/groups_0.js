var searchData=
[
  ['concurrency_20control_2e_635',['Concurrency control.',['../group__cc.html',1,'']]]
];
