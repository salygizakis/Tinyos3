var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyz",
  1: "_bcdflprstv",
  2: "bkstu",
  3: "abcdefgiklmoprstvwxy",
  4: "abcdefhiklmnoprstuvw",
  5: "cdfimprtuv",
  6: "dipst",
  7: "acdefinrsz",
  8: "fmp",
  9: "cdmprsu",
  10: "nt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

