var searchData=
[
  ['logrec_341',['logrec',['../structlogrec.html',1,'']]]
];
