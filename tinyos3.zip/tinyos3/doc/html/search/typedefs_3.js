var searchData=
[
  ['interrupt_571',['Interrupt',['../bios_8h.html#adae0801dc227f7fab2d61d0b7c9e9643',1,'bios.h']]],
  ['interrupt_5fhandler_572',['interrupt_handler',['../bios_8h.html#a11aeb47c6c66d331acd12556d0d4aedc',1,'bios.h']]]
];
