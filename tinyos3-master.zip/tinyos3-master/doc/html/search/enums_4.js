var searchData=
[
  ['thread_5fphase_599',['Thread_phase',['../group__scheduler.html#gab180b4aa356776bddcd724cef4f5deae',1,'kernel_sched.h']]],
  ['thread_5fstate_600',['Thread_state',['../group__scheduler.html#ga6c969c169777f82c104cf73e501df70f',1,'kernel_sched.h']]],
  ['thread_5ftype_601',['Thread_type',['../group__scheduler.html#ga18795bc1ab00161fc27ce34b1895fb03',1,'kernel_sched.h']]]
];
