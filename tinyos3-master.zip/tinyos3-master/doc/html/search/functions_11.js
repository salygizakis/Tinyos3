var searchData=
[
  ['waitchild_481',['WaitChild',['../group__syscalls.html#ga37017afba05480740d26b033975fef03',1,'tinyos.h']]],
  ['wakeup_482',['wakeup',['../group__scheduler.html#gae8301452fd9ae5bf7cd7f2676650ff06',1,'wakeup(TCB *tcb):&#160;kernel_sched.c'],['../group__scheduler.html#gae8301452fd9ae5bf7cd7f2676650ff06',1,'wakeup(TCB *tcb):&#160;kernel_sched.c']]],
  ['write_483',['Write',['../group__syscalls.html#gaf046f003fde24f79fb395c250137856c',1,'tinyos.h']]]
];
