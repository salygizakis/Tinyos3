var searchData=
[
  ['logrec_342',['logrec',['../structlogrec.html',1,'']]]
];
