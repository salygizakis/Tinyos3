var searchData=
[
  ['concurrency_20control_2e_637',['Concurrency control.',['../group__cc.html',1,'']]]
];
