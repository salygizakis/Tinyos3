var searchData=
[
  ['id_515',['id',['../structcore__control__block.html#a5208867f309bdd1656fd473f38b30bfe',1,'core_control_block']]],
  ['idle_5fthread_516',['idle_thread',['../structcore__control__block.html#a6dd29dab4a95ce740f45370345408c52',1,'core_control_block']]],
  ['its_517',['its',['../structthread__control__block.html#a68760c9f4ba9130ee8489d3e0bc2ec15',1,'thread_control_block']]]
];
