var searchData=
[
  ['bites_490',['bites',['../structsymposium__t.html#a9ee1b978200b8a4b7c30b170c1f20643',1,'symposium_t']]],
  ['bootfunc_491',['bootfunc',['../structvm__config.html#a9eb4f640012b1bcf02ae982e551b5767',1,'vm_config']]]
];
