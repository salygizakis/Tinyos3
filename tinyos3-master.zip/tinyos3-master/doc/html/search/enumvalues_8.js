var searchData=
[
  ['sched_5fidle_617',['SCHED_IDLE',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbea525b9af8477ce2505c0d559940d827e5',1,'kernel_sched.h']]],
  ['sched_5fio_618',['SCHED_IO',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbeaa19b25dfae8d75a5900bb23a1f6c64d8',1,'kernel_sched.h']]],
  ['sched_5fmutex_619',['SCHED_MUTEX',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbea7d3764881e09d1f0dbf2d8ef09640a37',1,'kernel_sched.h']]],
  ['sched_5fpipe_620',['SCHED_PIPE',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbea5f78cf7f43e406215d39f936fa99fd5a',1,'kernel_sched.h']]],
  ['sched_5fpoll_621',['SCHED_POLL',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbea1b7d43bbe4e4eb4089beb28b2c8f7e50',1,'kernel_sched.h']]],
  ['sched_5fquantum_622',['SCHED_QUANTUM',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbea99764e3e8f3195b33e888c816c9a0207',1,'kernel_sched.h']]],
  ['sched_5fuser_623',['SCHED_USER',['../group__scheduler.html#ggaad787d8d80312ffca3c0f197b3a25fbea9ead280a8852a73f1ba3368d66338275',1,'kernel_sched.h']]],
  ['serial_5frx_5fready_624',['SERIAL_RX_READY',['../bios_8h.html#a137af7bce5ff764f5c0aa4550086deaaa2e06ea796d072595be1770c601e78206',1,'bios.h']]],
  ['serial_5ftx_5fready_625',['SERIAL_TX_READY',['../bios_8h.html#a137af7bce5ff764f5c0aa4550086deaaad168539d997c69c61da9c1f5f3187878',1,'bios.h']]],
  ['shutdown_5fboth_626',['SHUTDOWN_BOTH',['../group__syscalls.html#gga9eb10a0a72ca3149140272e9344a272bab67e72e17566af8eb432d0f3eba6d44d',1,'tinyos.h']]],
  ['shutdown_5fread_627',['SHUTDOWN_READ',['../group__syscalls.html#gga9eb10a0a72ca3149140272e9344a272bacbd27e0b4e3d4a02b0d833f919887d2d',1,'tinyos.h']]],
  ['shutdown_5fwrite_628',['SHUTDOWN_WRITE',['../group__syscalls.html#gga9eb10a0a72ca3149140272e9344a272ba9a7920b6a1eb57633bb981aa60edbe24',1,'tinyos.h']]],
  ['stopped_629',['STOPPED',['../group__scheduler.html#gga6c969c169777f82c104cf73e501df70fa948b2aee15f52b421fa4770c47bcfe8c',1,'kernel_sched.h']]]
];
