var searchData=
[
  ['pipe_5fs_343',['pipe_s',['../structpipe__s.html',1,'']]],
  ['process_5fcontrol_5fblock_344',['process_control_block',['../structprocess__control__block.html',1,'']]],
  ['process_5fthread_5fcontrol_5fblock_345',['Process_Thread_Control_Block',['../structProcess__Thread__Control__Block.html',1,'']]],
  ['procinfo_346',['procinfo',['../structprocinfo.html',1,'']]],
  ['program_5farguments_347',['program_arguments',['../structprogram__arguments.html',1,'']]]
];
