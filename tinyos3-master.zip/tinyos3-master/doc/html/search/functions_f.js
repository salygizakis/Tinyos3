var searchData=
[
  ['threaddetach_473',['ThreadDetach',['../group__syscalls.html#ga5f957d985678728a418ff70a617fab4d',1,'tinyos.h']]],
  ['threadexit_474',['ThreadExit',['../group__syscalls.html#gab77e59bf31165db88a22ac8f031b8741',1,'tinyos.h']]],
  ['threadjoin_475',['ThreadJoin',['../group__syscalls.html#ga9ffbb344eb33487ceef5442846a74be0',1,'tinyos.h']]],
  ['threadself_476',['ThreadSelf',['../group__syscalls.html#ga75ffeb50fda6297110a2f07ef94d285c',1,'tinyos.h']]]
];
